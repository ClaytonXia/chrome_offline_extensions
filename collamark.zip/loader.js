var $css, $first_js, $head, $html, $jquery, $js, collamark_type;

collamark_type = document.getElementsByTagName('html')[0].getAttribute('collamark');

$first_js = document.getElementsByTagName('script')[0];

if (collamark_type == null) {
  $css = document.createElement('link');
  $css.setAttribute('rel', 'stylesheet');
  $css.setAttribute('href', chrome.extension.getURL('collamark_together.css'));
  $head = document.getElementsByTagName('head')[0];
  $head.appendChild($css);
  if (!window.jQuery) {
    $jquery = document.createElement('script');
    $jquery.src = chrome.extension.getURL('jquery-1.8.1.min.js');
    if ($first_js) {
      $first_js.parentNode.insertBefore($jquery, $first_js);
    } else {
      document.getElementsByTagName('body')[0].appendChild($jquery);
    }
  }
  $js = document.createElement('script');
  $js.src = chrome.extension.getURL('collamark_together.js');
  if ($first_js) {
    $first_js.parentNode.insertBefore($js, $first_js);
  } else {
    document.getElementsByTagName('body')[0].appendChild($js);
  }
  $html = document.getElementsByTagName('html')[0];
  $html.setAttribute('collamark', 'crx');
}

chrome.extension.sendMessage({
  tag: 'WANT-PALETTE'
}, function(response) {
  var $conf_js, conf_code;
  $conf_js = document.createElement('script');
  $conf_js.type = 'text/javascript';
  conf_code = "		var collamark_conf_user = {			palette: '" + response.palette + "'		}		";
  $conf_js.innerText = conf_code;


  if ($first_js) {
    return $first_js.parentNode.insertBefore($conf_js);
  } else {
    return document.getElementsByTagName('body')[0].appendChild($conf_js);
  }
});
